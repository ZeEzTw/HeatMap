#include "ConfigData.h"
#include <WiFi.h>
#include <WiFiClientSecure.h>


void sendTelegramMessage(const String &message);