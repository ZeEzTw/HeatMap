#include "ConfigData.h"
#include "Error.h"


// Enhanced InfluxDB writing with comprehensive error handling
void writeToInfluxDB(const String &body);
